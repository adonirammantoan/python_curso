#!/usr/bin/python3
v = "aeiou"
import sys
def main():
	comand = sys.argv[1].lower()
	message = sys.argv[2].lower()
	print (comand,message,sep= '\n')
	if 
main()