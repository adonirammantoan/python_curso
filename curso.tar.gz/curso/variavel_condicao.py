#!/usr/bin/python3
lista = [1, 5, 6, 8, 15, 156, 1235, 15, 25, 2, 4, 89, 88, 100]
x = [l for l in lista if l % 2 == 0]
print (x)