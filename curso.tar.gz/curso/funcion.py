#!/usr/bin/python3	
import sys 
def main():
	comando = float (sys.argv[1].lower())
	mensagem = sys.argv[2].lower()
	print (comando)
	print (mensagem)

if __name__=='__main__':
	main()