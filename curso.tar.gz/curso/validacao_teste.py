#!/usr/bin/python3
def somar(x, y):
    return x - y

assert somar(2,5) == 7, "o resultado é != de 7"