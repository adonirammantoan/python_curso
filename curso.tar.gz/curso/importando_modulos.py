#!/usr/bin/python3
import datetime, os
a = datetime.datetime.now().strftime('%d-%m-%y')
print (a)
b = os.system ('date')
print (b) 

