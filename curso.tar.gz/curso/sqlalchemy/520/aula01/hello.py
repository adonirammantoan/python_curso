#!/usr/bin/python
mensagem = 'seja bem vindo'
nome = input('Digite seu nome: ')
print(mensagem, nome, sep=':', end='\n\n')
