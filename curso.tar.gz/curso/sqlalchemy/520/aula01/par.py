#!/usr/bin/python3
'''
Criar uma lista de numerica de 0 até 100 com numeros pares.
'''
numeros = [1,5,2,6,8,9,1002, 3041, 762]
# par = [x for x in numeros if x % 2 == 0]
# print(par)
par = []
impar = []

for x in numeros:
    if x % 2 == 0:
        print()
        continue
    impar.append(x)





print(impar)
