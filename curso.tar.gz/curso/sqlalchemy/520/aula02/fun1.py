
var = 10

def escopo():
    global var
    var = 5
    print(var)

escopo()
print(var)
# def soma(x=2, y=2):
#     '''função que soma dois numeros'''
#     return x + y

# print(soma(y=2,x=6))
# a = soma()
# print(a)