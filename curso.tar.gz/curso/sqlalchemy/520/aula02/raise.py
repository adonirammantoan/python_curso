#!/usr/bin/python3

''' chmod +x $(ls)'''

try:
    ling = input('Qual a melhor linguagem\
                 de programação')
    if ling.lower().strip() != 'python':
        raise ValueError("linguagem errada!")

except ValueError as e:
    print(e)