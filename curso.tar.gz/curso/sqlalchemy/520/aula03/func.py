def pessoas(*nomes):
    for x in nomes:
        print(x)

def cadastro(**kwargs):
    
    print(kwargs)

pessoas('daniel', 'pedro', 'joao')

cadastro(nome='daniel', sobrenome='prata', idade=24)