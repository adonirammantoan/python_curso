from sqlalchemy import update
from core import user_table, engine

con = engine.connect()

atualizar = update(user_table).where(user_table.c.nome == 'daniel prata')

commit = atualizar.values(nome='user01')
result = con.execute(commit)
print(result.rowcount)